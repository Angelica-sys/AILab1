package main;

import com.eudycontreras.othello.capsules.AgentMove;
import com.eudycontreras.othello.capsules.MoveWrapper;
import com.eudycontreras.othello.capsules.ObjectiveWrapper;
import com.eudycontreras.othello.controllers.Agent;
import com.eudycontreras.othello.controllers.AgentController;
import com.eudycontreras.othello.enumerations.PlayerTurn;
import com.eudycontreras.othello.models.GameBoardState;

import java.util.List;
import java.util.Date;

public class AI extends Agent {

    public AI(PlayerTurn playerTurn) {
        super(playerTurn);
    }

    public AI(String agentName) {
        super(agentName);
    }

    public AI(String agentName, PlayerTurn playerTurn) {
        super(agentName, playerTurn);
    }


    @Override
    public AgentMove getMove(GameBoardState gameState) {
        //If the Player/Agent is NOT Terminal We need to reset the counter of the Methods in AgentMove

        setNodesExamined(0);
        setPrunedCounter(0);
        setReachedLeafNodes(0);
        setSearchDepth(0);

        //Run miniMax algorithm and the time of its execution
        long beforeAlgorithmTime = new Date().getTime();
        int buildThree = minimaxThreeBuild(gameState, 0, true, Integer.MIN_VALUE, Integer.MAX_VALUE);
        long afterAlgorithmTime = new Date().getTime();
        long timeForAlgorithmToExecute = (afterAlgorithmTime - beforeAlgorithmTime);
        System.out.println("Time for miniMax search is: " + timeForAlgorithmToExecute + " ms");

        //Match an available move with the return Value of the miniMax Alpha Beta pruning search.
        ObjectiveWrapper agentMove = null;
        List<GameBoardState> states = gameState.getChildStates();
        for (GameBoardState state : states) {
            if (state.utility == buildThree) {
                agentMove = state.getLeadingMove();
                break;
            }
        }

        // Error handeling if there is a utility of a node and the return value of the miniMax Alpha Beta Pruning algorithm was not found,
        //it is not a pretty error catching but it will suffice.
        if (agentMove == null) {
            agentMove = states.get(0).getLeadingMove();
        }
        return new MoveWrapper(agentMove);
        //If there is no possible move for the Agent i will return null and skip to next players turn.
        return new MoveWrapper(null);
        
    }
    /**
     * The algorithm for building the tree and the alpha-beta pruning-miniMax algorithm.
     * @param node parent node whose children will be traversed
     * @param depth depth of parent node
     * @param isMaximizing true if maximizing player
     * @param alpha alpha-value
     * @param beta beta-value
     * @return utility value of
     */
    private static int MAX_TREE_DEPTH = 8;
    private int minimaxThreeBuild(GameBoardState node, int depth, boolean isMaximizing, int alpha, int beta) {
        //set the boxes on the game board
        setSearchDepth(depth);
        setNodesExamined(getNodesExamined() + 1);
        int value = 0;


        //If we reach a leaf node, then we return the utility Value
        if (depth == MAX_TREE_DEPTH) return getUtility(node);

        if (isMaximizing) {
            //Get all available moves for max Player
            List<ObjectiveWrapper> possibleMoves = AgentController.getAvailableMoves(node, PlayerTurn.PLAYER_ONE);
            value = Integer.MIN_VALUE;

            //Traverse / iterade through all available moves for the max player
            for (ObjectiveWrapper move : possibleMoves) {
                GameBoardState childState = AgentController.getNewState(node, move);
                value = Math.max(value, minimaxThreeBuild(childState, depth + 1, false, alpha, beta));
                //if utility value is bigger or equal to beta then prune
                if (value >= beta) {
                    setPrunedCounter(getPrunedCounter() + 1); // increment the counter for each iteration
                    node.utility = value; // set the utility value of the node that was reached so that we can check what move to choose after the algorithm has executed
                    return value;

                }
                node.addChildState(childState);
                alpha = Math.max(alpha, value);
            }
            node.utility = value;

        }
        //Get all available moves for min Player ( if isMaximizing = false
        else if (!isMaximizing) {
            List<ObjectiveWrapper> possibleMoves = AgentController.getAvailableMoves(node, PlayerTurn.PLAYER_TWO);
            value = Integer.MIN_VALUE;
            for (ObjectiveWrapper move : possibleMoves) {
                GameBoardState childState = AgentController.getNewState(node, move);
                value = Math.min(value, minimaxThreeBuild(childState, depth + 1, true, alpha, beta));
                //if utility value is less than or equal to alpha then prune
                if (value <= alpha) {
                    setPrunedCounter(getPrunedCounter() + 1);
                    node.utility = value;
                }

            }

        }return value;

    }
    private int getUtility(GameBoardState node)
    {
        setReachedLeafNodes(getReachedLeafNodes() + 1);
        return (node.getWhiteCount() - node.getBlackCount());
    }
}




