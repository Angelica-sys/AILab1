package main;

import com.eudycontreras.othello.capsules.AgentMove;
import com.eudycontreras.othello.capsules.MoveWrapper;
import com.eudycontreras.othello.capsules.ObjectiveWrapper;
import com.eudycontreras.othello.controllers.Agent;
import com.eudycontreras.othello.controllers.AgentController;
import com.eudycontreras.othello.enumerations.PlayerTurn;
import com.eudycontreras.othello.models.GameBoardState;

import java.util.List;
import java.util.Date;

public class AI extends Agent {

    private static int MAX_TREE_DEPTH = 8;

    public AI(PlayerTurn playerTurn) {
        super(playerTurn);
    }

    public AI(String agentName) {
        super(agentName);
    }

    public AI(String agentName, PlayerTurn playerTurn) {
        super(agentName, playerTurn);
    }
    @Override
    public AgentMove getMove(GameBoardState gameState)
    {
        //If the Agent is NOT Terminal meaning that the AI has won the game, we need to make a move and reset the counter of the Methods in AgentMove
        if (!AgentController.isTerminal(gameState, PlayerTurn.PLAYER_ONE)) {
            setNodesExamined(0);
            setPrunedCounter(0);
            setReachedLeafNodes(0);
            setSearchDepth(0);

            //Run miniMax algorithm and calculate the time of its execution
            long timeBeforeABPruning = new Date().getTime();
            int minimaxThreeBuild = minimaxThreeBuild(gameState, 0, true, UserSettings.MIN_VALUE, UserSettings.MAX_VALUE);
            long timeAfterABPruning = new Date().getTime();

            long timeForAlgorithmToExecute = (timeAfterABPruning - timeBeforeABPruning);
            System.out.println("Time for miniMax search is: " + timeForAlgorithmToExecute + " ms");

            //Match an available move with the utility Value of the minimaxThreeBuild Alpha Beta pruning search.
            ObjectiveWrapper agentMove = null;
            List<GameBoardState> states = gameState.getChildStates();
            //for all states in the list of game board states and check so that is matches the value returned from the algorithm search
            for (GameBoardState state : states) {
                if (state.utilityValue == minimaxThreeBuild) {
                    agentMove = state.getLeadingMove(); //Leading move, gets the move that created this current state
                    break;
                }
            }

            // Error handling, "if there is a utility of a node and the return value of the miniMax Alpha Beta Pruning algorithm was not found"
            if (agentMove == null) {
                agentMove = states.get(0).getLeadingMove();
            }
            return new MoveWrapper(agentMove);
        }
        //If there is no possible move for the AI Agent, we will return null and skip to next players turn.
        return new MoveWrapper(null);
    }

    /**
     * minimaxThreeBuild is the algorithm for building the tree and the alpha-beta pruning-miniMax algorithm.
     * @param node parent node whose children will be traversed
     * @param depth depth of parent node
     * @param maximizingPlayer true if maximizing player
     * @param alpha alpha-value
     * @param beta beta-value
     * @return the utility value of AI move
     */

    private int minimaxThreeBuild(GameBoardState node, int depth, boolean maximizingPlayer, int alpha, int beta) {

        //set the boxes on the GUI game board
        setSearchDepth(depth);
        setNodesExamined(getNodesExamined() + 1);
        int value = 0;


        //If we reached the leaf node in maximal depth, then we return the utility Value
        if (depth == MAX_TREE_DEPTH) return getUtility(node);

        //If maximizingPlayer is true
        if (maximizingPlayer) {
            //Get all available moves for max Player
            List<ObjectiveWrapper> possibleMoves = AgentController.getAvailableMoves(node, PlayerTurn.PLAYER_ONE);
            value = UserSettings.MIN_VALUE;

            //Traverse / iterate through all available moves for the max player saved in the list
            for (ObjectiveWrapper move : possibleMoves) {
                GameBoardState childState = AgentController.getNewState(node, move);
                value = Math.max(value, minimaxThreeBuild(childState, depth + 1, false, alpha, beta));

                //if utility value is bigger or equal to beta then prune remaining child nodes that does not affect the final utility value.
                if (value >= beta) {
                    setPrunedCounter(getPrunedCounter() + 1); // increment the pruned counter for each iteration, so we don't go back and look at already pruned nodes
                    node.utilityValue = value; // set the utility value of the node that was reached so that we can check what move to choose after the algorithm has executed
                    return value;

                }
                node.addChildState(childState);
                alpha = Math.max(alpha, value);
            }
            node.utilityValue = value; //utility = payoff value

        }
        //Get all available moves for min Player ( if maximizingPlayer = false )
        else if (!maximizingPlayer) {
            List<ObjectiveWrapper> possibleMoves = AgentController.getAvailableMoves(node, PlayerTurn.PLAYER_TWO);
            value = UserSettings.MIN_VALUE;
            for (ObjectiveWrapper move : possibleMoves) {
                GameBoardState childState = AgentController.getNewState(node, move);
                value = Math.min(value, minimaxThreeBuild(childState, depth + 1, true, alpha, beta));

                //if utility value is less than or equal to alpha then prune remaining child nodes that does not affect the final utility value.
                if (value <= alpha) {
                    setPrunedCounter(getPrunedCounter() + 1);
                    node.utilityValue = value;
                    return value;
                }
                node.addChildState(childState);
                beta = Math.min(beta, value);

            }
            node.utilityValue =value;
        }

        return value;
    }


    private int getUtility(GameBoardState node)
    {
        setReachedLeafNodes(getReachedLeafNodes() + 1);
        return (node.getWhiteCount() - node.getBlackCount());
    }


}




