package main;
import com.eudycontreras.othello.capsules.AgentMove;
import com.eudycontreras.othello.capsules.ObjectiveWrapper;
import com.eudycontreras.othello.controllers.Agent;
import com.eudycontreras.othello.enumerations.PlayerTurn;
import com.eudycontreras.othello.models.GameBoardCell;
import com.eudycontreras.othello.models.GameBoardState;
import com.eudycontreras.othello.utilities.TraversalUtility;

import java.lang.reflect.Array;
import java.util.List;

public class State extends AgentMove {
    private final int MAX = Integer.MAX_VALUE;
    private final int MIN = Integer.MIN_VALUE;
    private int maxDepth;
    private static Runtime r;
    private PlayerTurn playerTurn;
    private GameBoardState gameState;


    public State(PlayerTurn playernTurn, int maxDepth, GameBoardState gameState) {
        this.playerTurn = playernTurn;
        this.maxDepth = maxDepth;
        this.gameState = gameState;
        r = Runtime.getRuntime();
        r.gc();
    }


    public int minimax(int depth, int nodeIndex, Boolean maximizingPlayer, int values[], int alpha, int beta)
    {
        // Terminating condition. i.e
        // leaf node is reached
       // if (depth == 3)
       //     return values[nodeIndex];


        if (maximizingPlayer)
        {
            int best = MIN;

            // Recur for left and
            // right children
            for (int i = 0; i < 2; i++)
            {
                int val = minimax(depth + 1, nodeIndex * 2 + i,
                        false, values, alpha, beta);
                best = Math.max(best, val);
                alpha = Math.max(alpha, best);

                // Alpha Beta Pruning
                if (beta <= alpha)
                    break;
            }
            return best;
        }
        else
        {
            int best = MAX;

            // Recur for left and
            // right children
            for (int i = 0; i < 2; i++)
            {

                int val = minimax(depth + 1, nodeIndex * 2 + i,
                        true, values, alpha, beta);
                best = Math.min(best, val);
                beta = Math.min(beta, best);

                // Alpha Beta Pruning
                if (beta <= alpha)
                    break;
            }
            return best;
        }
    }
    // Driver Code
    public int[] getPlayerAvailableCells (GameBoardCell gameBoardCell, int maxDepth) {
        List<ObjectiveWrapper> availableMoves = TraversalUtility.getAvailableCells(gameBoardCell, maxDepth);
        int values[] = availableMoves[];
        return values;
    }
    /**
     * Define a comparator for comparing the
     * reward of a move.
     */

    public int compareTo(AgentMove move) {

        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * Define what classifies a move as valid.
     */

    public boolean isValid() {
        //???
        // TODO Auto-generated method stub
        return false;
    }

}
